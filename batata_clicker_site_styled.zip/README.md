# Batata Clicker — Versão Estilizada para Site (sem save)

Esta versão mantém a interface estilizada (igual ao exemplo enviado) e **não** salva progresso — ideal para publicar como site público.

Arquivos incluídos:
- `index.html` — jogo principal (HTML + CSS + JS embutidos).

## Publicar no GitHub Pages
1. Crie um repositório novo no GitHub.
2. Faça upload do `index.html` na branch `main`.
3. Vá em Settings > Pages e selecione `main` branch, pasta `/ (root)`.
4. Aguarde alguns minutos — seu site ficará disponível em `https://<usuario>.github.io/<repo>/`.

Quer que eu gere o ZIP com esses arquivos para download?